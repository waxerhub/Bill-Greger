const fs=require('fs');
let src=fs.readFileSync('SpellEngine.jsx','utf8');

// 1. After conB, add wisAdj and dexMis computed vars
const OLD1='  var conB=conHP(adjStats.Con,classData.group);\n  var slots=';
const NEW1='  var conB=conHP(adjStats.Con,classData.group);\n  var wisAdj=wisDefense(adjStats.Wis);\n  var dexMis=dexMissile(adjStats.Dex);\n  var slots=';

if(!src.includes(OLD1)){console.log('ERROR: OLD1 not found');process.exit(1);}
src=src.replace(OLD1,NEW1);
console.log('Step 1 done: added wisAdj and dexMis vars');

// 2. Update combat rows: "Dex Adj" -> "Dex Def" and Movement row -> also show Dex Missile
const OLD2=
'              <Row l={buffAC>0?"AC*":"AC"} v={effAC} l2="Dex Adj" v2={dexAC(adjStats.Dex)} />\n' +
'              <Row l="HP" v={hp} l2={buffStr>0?"Dmg Adj*":"Dmg Adj"} v2={(effStrB.dmg>=0?"+":"")+effStrB.dmg} />\n' +
'              <Row l="Hit Dice" v={"d"+classData.hd} l2="Con Adj" v2={(conB>=0?"+":"")+conB+"/die"} />\n' +
'              <Row l="Movement" v={12} l2="" v2="" />';

const NEW2=
'              <Row l={buffAC>0?"AC*":"AC"} v={effAC} l2="Dex Def" v2={(dexAC(adjStats.Dex)>=0?"+":"")+dexAC(adjStats.Dex)} />\n' +
'              <Row l="HP" v={hp} l2={buffStr>0?"Dmg Adj*":"Dmg Adj"} v2={(effStrB.dmg>=0?"+":"")+effStrB.dmg} />\n' +
'              <Row l="Hit Dice" v={"d"+classData.hd} l2="Con Adj" v2={(conB>=0?"+":"")+conB+"/die"} />\n' +
'              <Row l="Movement" v={12} l2="Dex Missile" v2={(dexMis>=0?"+":"")+dexMis} />';

if(!src.includes(OLD2)){console.log('ERROR: OLD2 not found');process.exit(1);}
src=src.replace(OLD2,NEW2);
console.log('Step 2 done: updated combat rows');

// 3. Update saves to apply WIS magical defense adjustment to Rod and Spell saves
const OLD3=
'                var sbuff=buffSave>0&&s!=="Spell"?buffSave:0;var sv=saves[s]-sbuff;return <Row key={s} l={(sbuff>0?"* ")+(n[s]||s)} v={sv} l2="" v2="" />;';
const OLD3b=
'                var sbuff=buffSave>0&&s!==\"Spell\"?buffSave:0;var sv=saves[s]-sbuff;return <Row key={s} l={(sbuff>0?\"* \":\"\")+(n[s]||s)} v={sv} l2=\"\" v2=\"\" />;';

if(!src.includes(OLD3b)){console.log('ERROR: OLD3 not found');process.exit(1);}
const NEW3b=
'                var sbuff=buffSave>0&&s!==\"Spell\"?buffSave:0;\n' +
'                var wisAdj2=(s===\"Spell\"||s===\"Rod\")?wisAdj:0;\n' +
'                var sv=saves[s]-sbuff-wisAdj2;\n' +
'                var note=sbuff>0?\"* \":wisAdj2!==0?(wisAdj2>0?\"\\u2665 \":\"\\u2666 \"):\"\";\n' +
'                return <Row key={s} l={note+(n[s]||s)} v={sv} l2=\"\" v2=\"\" />;';
src=src.replace(OLD3b,NEW3b);
console.log('Step 3 done: saves now include WIS magical defense adj for Rod/Spell');

fs.writeFileSync('SpellEngine.jsx',src,'utf8');
console.log('SpellEngine.jsx sheet tab updated successfully.');
